@ECHO off
chcp 65001 >nul
cls
setlocal EnableExtensions
for /F %%E in ('echo prompt $E ^| cmd /d /q') do set "statusEsc=%%E"
set "errstep=Arbeitsverzeichnis wechseln"
set "script_dir=%~dp0"
if "%script_dir:~-1%"=="\" set "script_dir=%script_dir:~0,-1%"
cd /d "%script_dir%"
if errorlevel 1 goto :error
echo ========================================
echo Brautomat32 Flash ESP32-IDF5 Development
echo ========================================
echo.
echo %statusEsc%[44;30m INFO %statusEsc%[0m COM-Port pruefen und ESP32 per USB verbinden.
echo %statusEsc%[44;30m INFO %statusEsc%[0m Chip: ESP32, Baudrate: 921600, Port: automatische Erkennung
echo.
set "errstep=Flash-Speicher löschen"
echo %statusEsc%[44;30m INFO %statusEsc%[0m [1/2] Gesamten Flash-Speicher löschen; gespeicherte Daten werden entfernt.
"%script_dir%\esptool.exe" --chip esp32 --baud 921600 --before default-reset --after hard-reset erase-flash
if errorlevel 1 goto :error
echo %statusEsc%[42;30m DONE %statusEsc%[0m Flash-Speicher gelöscht.
set "errstep=Firmware und Dateisystem schreiben"
echo %statusEsc%[44;30m INFO %statusEsc%[0m [2/2] Bootloader, Partitionen, Boot-App, Firmware und LittleFS schreiben.
"%script_dir%\esptool.exe" --chip esp32 --baud 921600 --before default-reset --after hard-reset write-flash --no-progress 0x1000 "%script_dir%\bootloader.bin" 0x8000 "%script_dir%\partitions.bin" 0xe000 "%script_dir%\boot_app0.bin" 0x10000 "%script_dir%\firmware.bin" 0x350000 "%script_dir%\Littlefs.bin"
if errorlevel 1 goto :error
echo.
echo %statusEsc%[42;30m DONE %statusEsc%[0m Flashvorgang erfolgreich abgeschlossen; ESP32 wird neu gestartet.
pause
exit /b 0

:error
set "flashExit=%errorlevel%"
echo.
echo %statusEsc%[41;30m ERROR %statusEsc%[0m %errstep%. Exit code: %flashExit%
pause
exit /b %flashExit%
