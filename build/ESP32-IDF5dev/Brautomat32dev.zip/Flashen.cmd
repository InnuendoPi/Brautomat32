@ECHO off
chcp 65001 >nul
cls
setlocal EnableExtensions
set "script_dir=%~dp0"
if "%script_dir:~-1%"=="\" set "script_dir=%script_dir:~0,-1%"
cd /d "%script_dir%"
echo =============================================
echo Brautomat32 Flash ESP32-IDF5
echo =============================================
echo.
echo COM-Port pruefen und ESP32 per USB verbinden.
echo.
"%script_dir%\esptool.exe" --chip esp32 --baud 921600 --before default-reset --after hard-reset erase-flash
if errorlevel 1 goto :error
"%script_dir%\esptool.exe" --chip esp32 --baud 921600 --before default-reset --after hard-reset write-flash --no-progress 0x1000 "%script_dir%\bootloader.bin" 0x8000 "%script_dir%\partitions.bin" 0xe000 "%script_dir%\boot_app0.bin" 0x10000 "%script_dir%\firmware.bin" 0x350000 "%script_dir%\Littlefs.bin"
if errorlevel 1 goto :error
echo.
pause
exit /b 0

:error
echo.
echo Fehler beim Flashen. Exit code: %errorlevel%
pause
exit /b %errorlevel%
