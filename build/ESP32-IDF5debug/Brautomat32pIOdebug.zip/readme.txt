Baud: 115200 CRLF
do not use ESP32 IDF5 debug version. debug only.