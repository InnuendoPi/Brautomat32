@echo off
setlocal
rem Full flash with LittleFS. Use ServiceTool for migration with backup and restore.
pushd "%~dp0" || exit /b 1
for %%F in (esptool.exe bootloader.bin partitions.bin boot_app0.bin firmware.bin serviceapp.bin Littlefs.bin) do (
    if not exist "%%F" (
        echo [FEHLER] Paketdatei fehlt: %%F
        popd
        exit /b 1
    )
)
"%~dp0esptool.exe" --chip esp32 --baud 921600 --before default-reset --after hard-reset write-flash 0x1000 bootloader.bin 0x8000 partitions.bin 0xe000 boot_app0.bin 0x10000 firmware.bin 0x220000 serviceapp.bin 0x350000 Littlefs.bin
set "flashExit=%errorlevel%"
popd
exit /b %flashExit%
